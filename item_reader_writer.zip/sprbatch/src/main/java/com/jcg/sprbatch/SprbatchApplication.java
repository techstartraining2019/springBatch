package com.jcg.sprbatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprbatchApplication {

    public static void main(String[] args) {
        SpringApplication.run(SprbatchApplication.class, args);
    }
}
